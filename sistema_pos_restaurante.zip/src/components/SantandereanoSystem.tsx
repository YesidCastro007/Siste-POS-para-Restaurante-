import React, { useState } from 'react';
import { User, Lock, ChefHat, LogOut, UtensilsCrossed, X, Trash2, Plus, Minus, Send, CheckCircle, Clock, Calculator, BarChart3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';

// Datos de prueba
const USERS = {
  mesero1: { password: '1234', role: 'mesero', name: 'Juan Pérez' },
  cajera1: { password: '1234', role: 'cajera', name: 'María García' },
  dueño1: { password: '1234', role: 'dueño', name: 'Carlos Rodríguez' }
};

const MENU_DATA = {
  picadas: {
    sizes: ['Personal', 'Para 2', 'Para 4', 'Familiar'],
    carnes: ['Res', 'Cerdo', 'Rellena', 'Chorizo', 'Gallina'],
    terminos: ['Jugoso', '3/4', 'Bien cocido']
  },
  sopas: {
    price: 9000, // Precio fijo
    sabores: [] // Se cargará dinámicamente desde localStorage
  },
  bebidas: {
    'Jugos Hit y Gaseosas 350ml': [
      { name: 'Jugo Hit Mango', price: 3000 },
      { name: 'Jugo Hit Lulo', price: 3000 },
      { name: 'Jugo Hit Mora', price: 3000 },
      { name: 'Coca Cola 350ml', price: 3000 },
      { name: 'Pepsi 350ml', price: 3000 },
      { name: 'Sprite 350ml', price: 3000 }
    ],
    'Cervezas y Cola & Pola 350ml': [
      { name: 'Cerveza Aguila', price: 3500 },
      { name: 'Cerveza Poker', price: 3500 },
      { name: 'Cola & Pola 350ml', price: 3500 }
    ],
    'Gaseosas 1.5L': [
      { name: 'Coca Cola 1.5L', price: 6000 },
      { name: 'Pepsi 1.5L', price: 6000 },
      { name: 'Sprite 1.5L', price: 6000 }
    ],
    'Cola & Pola 1.5L': [
      { name: 'Cola & Pola 1.5L', price: 8000 }
    ]
  },
  adicionales: [
    { name: 'Porción de yuca', price: 4000, fixed: true },
    { name: 'Porción de papa', price: 4000, fixed: true },
    { name: 'Porción de plátano', price: 4000, fixed: true },
    { name: 'Guacamole', price: 3000, fixed: true },
    { name: 'Arepa', price: 2000, fixed: true }
  ]
};

const PISOS = [
  { number: 1, mesas: 15 },
  { number: 2, mesas: 18 },
  { number: 3, mesas: 10 }
];

export default function SantandereanoSystem() {
  const [currentUser, setCurrentUser] = useState(null);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('mesero');
  const [isHovered, setIsHovered] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleLogin = async () => {
    // Validar que los campos no estén vacíos
    if (!username.trim() || !password.trim()) {
      alert('Por favor ingrese usuario y contraseña');
      return;
    }

    setIsLoading(true);
    
    // Simular un pequeño delay para mejor UX
    await new Promise(resolve => setTimeout(resolve, 500));

    const user = USERS[username];
    if (user && user.password === password && user.role === role) {
      setCurrentUser({ username, ...user });
    } else {
      alert('Usuario, contraseña o rol incorrecto. Verifique las credenciales.');
    }
    
    setIsLoading(false);
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setUsername('');
    setPassword('');
    setRole('mesero'); // Reset al rol por defecto
  };

  if (!currentUser) {
    return <LoginScreen 
      username={username}
      setUsername={setUsername}
      password={password}
      setPassword={setPassword}
      role={role}
      setRole={setRole}
      handleLogin={handleLogin}
      isHovered={isHovered}
      setIsHovered={setIsHovered}
      isLoading={isLoading}
    />;
  }

  if (currentUser.role === 'mesero') {
    return <MeseroDashboard user={currentUser} onLogout={handleLogout} />;
  }

  if (currentUser.role === 'cajera') {
    return <CajeraDashboard user={currentUser} onLogout={handleLogout} />;
  }

  if (currentUser.role === 'dueño') {
    return <DueñoDashboard user={currentUser} onLogout={handleLogout} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-red-900 to-slate-900">
      <div className="container mx-auto px-4 py-8">
        <Card className="bg-white/10 backdrop-blur-md border-red-900/20">
          <CardHeader>
            <CardTitle className="text-white text-center">
              Panel de {currentUser.role}
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center text-gray-300">
            <p>Próximamente...</p>
            <Button 
              onClick={handleLogout}
              variant="outline"
              className="mt-4 border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Cerrar Sesión
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function LoginScreen({ username, setUsername, password, setPassword, role, setRole, handleLogin, isHovered, setIsHovered, isLoading }) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-red-900 to-slate-900 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl grid lg:grid-cols-2 gap-8 items-center">
        
        {/* Logo y branding */}
        <div className="hidden lg:flex flex-col items-center justify-center text-center space-y-8">
          <div className="relative">
            <div className="w-32 h-32 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center shadow-2xl shadow-red-600/50">
              <div className="w-24 h-24 bg-white/10 rounded-full flex items-center justify-center backdrop-blur-sm">
                <UtensilsCrossed className="w-12 h-12 text-white" />
              </div>
            </div>
            <div className="absolute -top-2 -right-2 w-8 h-8 bg-yellow-500 rounded-full flex items-center justify-center">
              <ChefHat className="w-4 h-4 text-yellow-900" />
            </div>
          </div>
          
          <div className="space-y-4">
            <h1 className="text-6xl font-bold text-white">
              Santandereano
            </h1>
            <p className="text-2xl text-red-300 font-light tracking-wider">
              SAS
            </p>
            <div className="w-24 h-1 bg-gradient-to-r from-red-600 to-yellow-500 mx-auto rounded-full"></div>
          </div>
        </div>

        {/* Formulario de login */}
        <Card className="bg-white/5 backdrop-blur-xl border-red-900/20 shadow-2xl">
          <CardHeader className="space-y-6">
            <div className="lg:hidden text-center">
              <div className="w-16 h-16 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center mx-auto mb-4">
                <UtensilsCrossed className="w-8 h-8 text-white" />
              </div>
              <h1 className="text-3xl font-bold text-white">Santandereano</h1>
              <p className="text-red-300">SAS</p>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-3">
                  Tipo de Usuario
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['dueño', 'cajera', 'mesero'].map((r) => (
                    <Button
                      key={r}
                      onClick={() => setRole(r)}
                      variant={role === r ? "default" : "outline"}
                      className={`py-3 px-4 text-sm font-medium transition-all duration-300 ${
                        role === r
                          ? 'bg-red-600 text-white shadow-lg shadow-red-600/50 scale-105 hover:bg-red-700'
                          : 'bg-white/5 text-gray-400 hover:bg-white/10 border-red-900/20 hover:border-red-600/50'
                      }`}
                    >
                      {r.charAt(0).toUpperCase() + r.slice(1)}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Usuario
                  </label>
                  <div className="relative">
                    <User className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <Input
                      type="text"
                      value={username}
                      onChange={(e) => setUsername(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                      className="w-full bg-white/5 border-red-900/30 pl-12 py-3 text-white placeholder-gray-500 focus:border-red-600 focus:ring-2 focus:ring-red-600/20"
                      placeholder="Ingrese su usuario"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Contraseña
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
                    <Input
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && handleLogin()}
                      className="w-full bg-white/5 border-red-900/30 pl-12 py-3 text-white placeholder-gray-500 focus:border-red-600 focus:ring-2 focus:ring-red-600/20"
                      placeholder="••••••••"
                    />
                  </div>
                </div>

                <Button
                  onClick={handleLogin}
                  disabled={isLoading}
                  onMouseEnter={() => setIsHovered(true)}
                  onMouseLeave={() => setIsHovered(false)}
                  className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-medium py-4 transition-all duration-300 shadow-lg shadow-red-600/30 hover:shadow-red-600/50 hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100"
                >
                  <span className="flex items-center justify-center gap-2">
                    {isLoading ? (
                      <>
                        <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                        Iniciando sesión...
                      </>
                    ) : (
                      <>
                        Iniciar Sesión
                        <span className={`transition-transform duration-300 ${isHovered ? 'translate-x-1' : ''}`}>
                          →
                        </span>
                      </>
                    )}
                  </span>
                </Button>

                <div className="text-center space-y-2">
                  <p className="text-xs text-gray-500">
                    Usuarios de prueba disponibles:
                  </p>
                  <div className="text-xs text-gray-400 space-y-1">
                    <p>• <span className="text-blue-400">mesero1</span> / 1234 (Mesero)</p>
                    <p>• <span className="text-green-400">cajera1</span> / 1234 (Cajera)</p>
                    <p>• <span className="text-yellow-400">dueño1</span> / 1234 (Dueño)</p>
                  </div>
                </div>
              </div>
            </div>
          </CardHeader>
        </Card>
      </div>
      
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 text-center text-gray-500 text-sm">
        Panel Administrativo • Santandereano SAS © 2025
      </div>
    </div>
  );
}

// Colores para diferentes meseros
const COLORES_MESEROS = {
  'Juan Pérez': 'blue',
  'María García': 'green', 
  'Carlos Rodríguez': 'purple',
  'Ana López': 'orange',
  'Luis Martínez': 'pink'
};

function MeseroDashboard({ user, onLogout }) {
  const [pisoActual, setPisoActual] = useState(1);
  const [mesaSeleccionada, setMesaSeleccionada] = useState(null);
  const [mesas, setMesas] = useState({});
  const [mostrarPedido, setMostrarPedido] = useState(false);
  const [mostrarAnalisis, setMostrarAnalisis] = useState(false);
  const [historialVentas, setHistorialVentas] = useState([]);
  const [mostrarCobro, setMostrarCobro] = useState(false);
  const [saboresSopas, setSaboresSopas] = useState([]);

  // Funciones de persistencia
  const cargarDatos = () => {
    try {
      const mesasGuardadas = localStorage.getItem('santandereano_mesas');
      const ventasGuardadas = localStorage.getItem('santandereano_ventas');
      const saboresGuardados = localStorage.getItem('santandereano_sabores_sopas');
      
      if (mesasGuardadas) {
        setMesas(JSON.parse(mesasGuardadas));
      }
      if (ventasGuardadas) {
        setHistorialVentas(JSON.parse(ventasGuardadas));
      }
      if (saboresGuardados) {
        setSaboresSopas(JSON.parse(saboresGuardados));
      } else {
        // Sabores por defecto si no hay guardados
        const saboresDefault = ['Sopa de costilla', 'Sancocho'];
        setSaboresSopas(saboresDefault);
        localStorage.setItem('santandereano_sabores_sopas', JSON.stringify(saboresDefault));
      }
    } catch (error) {
      console.error('Error cargando datos:', error);
    }
  };

  const guardarMesas = (nuevasMesas) => {
    try {
      localStorage.setItem('santandereano_mesas', JSON.stringify(nuevasMesas));
      setMesas(nuevasMesas);
      // Disparar evento para sincronizar con otros meseros
      window.dispatchEvent(new CustomEvent('mesasActualizadas', { detail: nuevasMesas }));
    } catch (error) {
      console.error('Error guardando mesas:', error);
    }
  };

  const guardarVentas = (nuevasVentas) => {
    try {
      localStorage.setItem('santandereano_ventas', JSON.stringify(nuevasVentas));
      setHistorialVentas(nuevasVentas);
    } catch (error) {
      console.error('Error guardando ventas:', error);
    }
  };

  // Cargar datos al montar el componente
  React.useEffect(() => {
    cargarDatos();
    
    // Escuchar cambios de otros meseros
    const handleMesasActualizadas = (event) => {
      setMesas(event.detail);
    };
    
    window.addEventListener('mesasActualizadas', handleMesasActualizadas);
    
    // Sincronizar cada 5 segundos
    const interval = setInterval(() => {
      cargarDatos();
    }, 5000);
    
    return () => {
      window.removeEventListener('mesasActualizadas', handleMesasActualizadas);
      clearInterval(interval);
    };
  }, []);

  const mesasDelPiso = PISOS.find(p => p.number === pisoActual)?.mesas || 0;

  const abrirMesa = (numeroMesa) => {
    setMesaSeleccionada(numeroMesa);
    setMostrarPedido(true);
  };

  const cerrarPedido = () => {
    setMostrarPedido(false);
    setMesaSeleccionada(null);
  };

  const procesarCobro = (mesaKey, mesaData) => {
    // Crear registro de venta
    const venta = {
      id: Date.now(),
      fecha: new Date().toISOString(),
      mesa: mesaKey,
      mesero: user.name,
      pedidos: mesaData.pedidos,
      total: mesaData.total,
      metodoPago: mesaData.metodoPago || 'efectivo'
    };

    // Agregar al historial y guardar
    const nuevasVentas = [...historialVentas, venta];
    guardarVentas(nuevasVentas);

    // Limpiar la mesa y guardar
    const nuevasMesas = { ...mesas };
    delete nuevasMesas[mesaKey];
    guardarMesas(nuevasMesas);

    // Cerrar modales
    setMostrarCobro(false);
    setMostrarPedido(false);
    setMesaSeleccionada(null);

    alert(`¡Cobro procesado exitosamente! Total: $${mesaData.total.toLocaleString()}`);
  };

  const abrirCobro = () => {
    setMostrarCobro(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-red-900 to-slate-900">
      {/* Header */}
      <div className="bg-white/5 backdrop-blur-md border-b border-red-900/20 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center">
                <UtensilsCrossed className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">
                  Santandereano SAS
                </h1>
                <p className="text-sm text-red-300">
                  Panel de Mesero
                </p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button
                onClick={() => setMostrarAnalisis(true)}
                variant="outline"
                size="sm"
                className="border-blue-600 text-blue-400 hover:bg-blue-600 hover:text-white"
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Análisis
              </Button>
              
              <div className="text-right">
                <p className="text-sm font-medium text-white">{user.name}</p>
                <p className="text-xs text-gray-400">Mesero</p>
              </div>
              <Button
                onClick={onLogout}
                variant="outline"
                size="sm"
                className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Selector de Pisos */}
        <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
          <CardContent className="p-6">
            <div className="grid grid-cols-3 gap-4">
              {PISOS.map((piso) => (
                <Button
                  key={piso.number}
                  onClick={() => setPisoActual(piso.number)}
                  variant={pisoActual === piso.number ? "default" : "outline"}
                  className={`flex-1 py-6 px-6 rounded-xl font-medium transition-all duration-300 ${
                    pisoActual === piso.number
                      ? 'bg-gradient-to-r from-red-600 to-red-700 text-white shadow-lg shadow-red-600/30'
                      : 'bg-white/5 text-gray-400 hover:bg-white/10 border-red-900/20'
                  }`}
                >
                  <div className="text-center">
                    <p className="text-lg font-bold">Piso {piso.number}</p>
                    <p className="text-sm opacity-80">{piso.mesas} mesas</p>
                  </div>
                </Button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Leyenda de Colores */}
        <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
          <CardContent className="p-4">
            <div className="flex flex-wrap items-center justify-center gap-4 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-green-600/20 border border-green-600 rounded"></div>
                <span className="text-gray-300">Disponible</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-blue-600/30 border border-blue-600 rounded"></div>
                <span className="text-gray-300">Mi Mesa</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-4 h-4 bg-purple-600/10 border border-purple-600/50 rounded"></div>
                <span className="text-gray-300">Otro Mesero</span>
              </div>
              <div className="text-gray-400 text-xs">
                📝 Cada mesero tiene su color único
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Grid de Mesas */}
        <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
          <CardHeader>
            <CardTitle className="text-white">Mesas - Piso {pisoActual}</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {Array.from({ length: mesasDelPiso }, (_, i) => {
                const numeroMesa = i + 1;
                const mesaKey = `${pisoActual}-${numeroMesa}`;
                const mesaData = mesas[mesaKey];
                const ocupada = mesaData && mesaData.pedidos?.length > 0;
                const meseroAsignado = mesaData?.mesero;
                const colorMesero = meseroAsignado ? COLORES_MESEROS[meseroAsignado] || 'red' : 'green';
                const esMiMesa = meseroAsignado === user.name;

                // Definir colores según el estado y mesero
                let clasesMesa = 'aspect-square rounded-xl p-4 flex flex-col items-center justify-center transition-all duration-300 hover:scale-105 ';
                
                if (ocupada) {
                  if (esMiMesa) {
                    // Mi mesa - color del mesero con mayor intensidad
                    clasesMesa += `bg-${colorMesero}-600/30 border-2 border-${colorMesero}-600 shadow-lg shadow-${colorMesero}-600/20 text-${colorMesero}-300`;
                  } else {
                    // Mesa de otro mesero - color tenue
                    clasesMesa += `bg-${colorMesero}-600/10 border-2 border-${colorMesero}-600/50 shadow-lg shadow-${colorMesero}-600/10 text-${colorMesero}-400`;
                  }
                } else {
                  // Mesa disponible
                  clasesMesa += 'bg-green-600/20 border-2 border-green-600/50 hover:border-green-500 text-green-300';
                }

                return (
                  <Button
                    key={numeroMesa}
                    onClick={() => abrirMesa(numeroMesa)}
                    variant="outline"
                    className={clasesMesa}
                  >
                    <UtensilsCrossed className="w-6 h-6 mb-2" />
                    <p className="text-lg font-bold">{numeroMesa}</p>
                    <p className="text-xs">
                      {ocupada ? (
                        esMiMesa ? 'Mi Mesa' : `${meseroAsignado}`
                      ) : 'Disponible'}
                    </p>
                    {ocupada && mesaData.total && (
                      <p className="text-xs font-medium mt-1">
                        ${mesaData.total.toLocaleString()}
                      </p>
                    )}
                    {ocupada && !esMiMesa && (
                      <p className="text-xs opacity-60 mt-1">
                        🔒 Otro mesero
                      </p>
                    )}
                  </Button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Modal de Pedido */}
      {mostrarPedido && (
        <ModalPedido
          pisoActual={pisoActual}
          mesaSeleccionada={mesaSeleccionada}
          mesas={mesas}
          setMesas={guardarMesas}
          onCerrar={cerrarPedido}
          onAbrirCobro={abrirCobro}
          user={user}
          saboresSopas={saboresSopas}
        />
      )}

      {/* Modal de Cobro */}
      {mostrarCobro && mesaSeleccionada && (
        <ModalCobro
          pisoActual={pisoActual}
          mesaSeleccionada={mesaSeleccionada}
          mesaData={mesas[`${pisoActual}-${mesaSeleccionada}`]}
          onCerrar={() => setMostrarCobro(false)}
          onProcesarCobro={(mesaData) => procesarCobro(`${pisoActual}-${mesaSeleccionada}`, mesaData)}
        />
      )}

      {/* Modal de Análisis */}
      {mostrarAnalisis && (
        <ModalAnalisis
          historialVentas={historialVentas}
          onCerrar={() => setMostrarAnalisis(false)}
        />
      )}
    </div>
  );
}

function CajeraDashboard({ user, onLogout }) {
  const [mesas, setMesas] = useState({});
  const [historialVentas, setHistorialVentas] = useState([]);
  const [saboresSopas, setSaboresSopas] = useState([]);
  const [nuevoSabor, setNuevoSabor] = useState('');
  const [mostrarGestionSopas, setMostrarGestionSopas] = useState(false);

  // Cargar datos
  const cargarDatos = () => {
    try {
      const mesasGuardadas = localStorage.getItem('santandereano_mesas');
      const ventasGuardadas = localStorage.getItem('santandereano_ventas');
      const saboresGuardados = localStorage.getItem('santandereano_sabores_sopas');
      
      if (mesasGuardadas) setMesas(JSON.parse(mesasGuardadas));
      if (ventasGuardadas) setHistorialVentas(JSON.parse(ventasGuardadas));
      if (saboresGuardados) {
        setSaboresSopas(JSON.parse(saboresGuardados));
      } else {
        const saboresDefault = ['Sopa de costilla', 'Sancocho'];
        setSaboresSopas(saboresDefault);
      }
    } catch (error) {
      console.error('Error cargando datos:', error);
    }
  };

  // Guardar sabores de sopas
  const guardarSabores = (nuevosSabores) => {
    try {
      localStorage.setItem('santandereano_sabores_sopas', JSON.stringify(nuevosSabores));
      setSaboresSopas(nuevosSabores);
      // Disparar evento para sincronizar
      window.dispatchEvent(new CustomEvent('saboresActualizados', { detail: nuevosSabores }));
    } catch (error) {
      console.error('Error guardando sabores:', error);
    }
  };

  // Agregar nuevo sabor
  const agregarSabor = () => {
    if (nuevoSabor.trim() && !saboresSopas.includes(nuevoSabor.trim())) {
      const nuevosSabores = [...saboresSopas, nuevoSabor.trim()];
      guardarSabores(nuevosSabores);
      setNuevoSabor('');
    }
  };

  // Eliminar sabor
  const eliminarSabor = (sabor) => {
    const nuevosSabores = saboresSopas.filter(s => s !== sabor);
    guardarSabores(nuevosSabores);
  };

  React.useEffect(() => {
    cargarDatos();
    const interval = setInterval(cargarDatos, 5000);
    return () => clearInterval(interval);
  }, []);

  const mesasOcupadas = Object.entries(mesas).filter(([_, data]) => data.pedidos?.length > 0);
  const totalVentas = mesasOcupadas.reduce((sum, [_, data]) => sum + data.total, 0);
  const ventasHoy = historialVentas.filter(venta => {
    const hoy = new Date().toDateString();
    const fechaVenta = new Date(venta.fecha).toDateString();
    return hoy === fechaVenta;
  });
  const totalHoy = ventasHoy.reduce((sum, venta) => sum + venta.total, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-red-900 to-slate-900">
      {/* Header */}
      <div className="bg-white/5 backdrop-blur-md border-b border-red-900/20 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center">
                <Calculator className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Santandereano SAS</h1>
                <p className="text-sm text-red-300">Panel de Cajera</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <Button
                onClick={() => setMostrarGestionSopas(true)}
                variant="outline"
                size="sm"
                className="border-blue-600 text-blue-400 hover:bg-blue-600 hover:text-white"
              >
                <ChefHat className="w-4 h-4 mr-2" />
                Gestionar Sopas
              </Button>
              
              <div className="text-right">
                <p className="text-sm font-medium text-white">{user.name}</p>
                <p className="text-xs text-gray-400">Cajera</p>
              </div>
              <Button
                onClick={onLogout}
                variant="outline"
                size="sm"
                className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Resumen de ventas */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm">Mesas Activas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-400">{mesasOcupadas.length}</p>
            </CardContent>
          </Card>

          <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm">Ventas Hoy</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-blue-400">${totalHoy.toLocaleString()}</p>
              <p className="text-xs text-gray-400 mt-1">{ventasHoy.length} órdenes</p>
            </CardContent>
          </Card>

          <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm">Sabores de Sopas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-yellow-400">{saboresSopas.length}</p>
              <p className="text-xs text-gray-400 mt-1">disponibles</p>
            </CardContent>
          </Card>
        </div>

        {/* Lista de mesas para facturar */}
        <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
          <CardHeader>
            <CardTitle className="text-white">Mesas para Facturar</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {mesasOcupadas.map(([mesaKey, mesaData]) => {
                const [piso, mesa] = mesaKey.split('-');
                return (
                  <Card key={mesaKey} className="bg-white/5 border-red-900/20">
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-white font-medium">Mesa {mesa} - Piso {piso}</h3>
                          <p className="text-gray-400 text-sm">{mesaData.pedidos.length} items</p>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-bold text-green-400">${mesaData.total.toLocaleString()}</p>
                          <Button size="sm" className="mt-2 bg-green-600 hover:bg-green-700">
                            Facturar
                          </Button>
                        </div>
                      </div>
                      
                      <Separator className="my-3 bg-red-900/20" />
                      
                      <div className="space-y-2">
                        {mesaData.pedidos.map((pedido) => (
                          <div key={pedido.id} className="flex justify-between items-center text-sm">
                            <span className="text-gray-300">
                              {pedido.tipo === 'picada' 
                                ? `Picada ${pedido.size} (${pedido.carnes.join(', ')})` 
                                : pedido.nombre
                              } x{pedido.cantidad}
                            </span>
                            <span className="text-white">
                              ${((pedido.tipo === 'picada' ? parseInt(pedido.precio) : pedido.precioItem) * pedido.cantidad).toLocaleString()}
                            </span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
      
      {/* Modal de Gestión de Sopas */}
      {mostrarGestionSopas && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <Card className="w-full max-w-md bg-white/5 backdrop-blur-md border-red-900/20">
            <CardHeader className="border-b border-red-900/20">
              <div className="flex items-center justify-between">
                <CardTitle className="text-white">Gestionar Sabores de Sopas</CardTitle>
                <Button
                  onClick={() => setMostrarGestionSopas(false)}
                  variant="outline"
                  size="sm"
                  className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="p-6 space-y-4">
              <div className="text-center">
                <p className="text-gray-400 text-sm mb-4">
                  Precio fijo: <span className="text-white font-bold">$9.000</span>
                </p>
              </div>
              
              {/* Agregar nuevo sabor */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">
                  Agregar Nuevo Sabor
                </label>
                <div className="flex space-x-2">
                  <Input
                    value={nuevoSabor}
                    onChange={(e) => setNuevoSabor(e.target.value)}
                    placeholder="Ej: Sopa de mondongo"
                    className="bg-white/5 border-red-900/30 text-white"
                    onKeyPress={(e) => e.key === 'Enter' && agregarSabor()}
                  />
                  <Button
                    onClick={agregarSabor}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
              </div>
              
              {/* Lista de sabores actuales */}
              <div className="space-y-2">
                <label className="block text-sm font-medium text-gray-300">
                  Sabores Disponibles ({saboresSopas.length})
                </label>
                <div className="max-h-60 overflow-y-auto space-y-2">
                  {saboresSopas.map((sabor, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                      <div>
                        <p className="text-white font-medium">{sabor}</p>
                        <p className="text-gray-400 text-sm">$9.000</p>
                      </div>
                      <Button
                        onClick={() => eliminarSabor(sabor)}
                        variant="outline"
                        size="sm"
                        className="bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white border-red-600/50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="text-center">
                <Button
                  onClick={() => setMostrarGestionSopas(false)}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  Guardar Cambios
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}

function DueñoDashboard({ user, onLogout }) {
  const ventasHoy = 450000;
  const mesasActivas = 8;
  const pedidosPendientes = 12;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-red-900 to-slate-900">
      {/* Header */}
      <div className="bg-white/5 backdrop-blur-md border-b border-red-900/20 sticky top-0 z-40">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="w-12 h-12 bg-gradient-to-br from-red-600 to-red-800 rounded-full flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Santandereano SAS</h1>
                <p className="text-sm text-red-300">Panel de Administración</p>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              <div className="text-right">
                <p className="text-sm font-medium text-white">{user.name}</p>
                <p className="text-xs text-gray-400">Dueño</p>
              </div>
              <Button
                onClick={onLogout}
                variant="outline"
                size="sm"
                className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-6 space-y-6">
        {/* Métricas principales */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm">Ventas Hoy</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-green-400">${ventasHoy.toLocaleString()}</p>
              <p className="text-xs text-gray-400 mt-1">+12% vs ayer</p>
            </CardContent>
          </Card>

          <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm">Mesas Activas</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-blue-400">{mesasActivas}</p>
              <p className="text-xs text-gray-400 mt-1">de 43 totales</p>
            </CardContent>
          </Card>

          <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm">Pedidos Pendientes</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-yellow-400">{pedidosPendientes}</p>
              <p className="text-xs text-gray-400 mt-1">en cocina</p>
            </CardContent>
          </Card>

          <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
            <CardHeader className="pb-3">
              <CardTitle className="text-white text-sm">Promedio Ticket</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-3xl font-bold text-purple-400">${Math.round(ventasHoy / 25).toLocaleString()}</p>
              <p className="text-xs text-gray-400 mt-1">25 órdenes</p>
            </CardContent>
          </Card>
        </div>

        {/* Productos más vendidos */}
        <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
          <CardHeader>
            <CardTitle className="text-white">Productos Más Vendidos Hoy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[
                { nombre: 'Picada Personal', cantidad: 15, total: 225000 },
                { nombre: 'Sopa de Costilla', cantidad: 12, total: 120000 },
                { nombre: 'Cerveza', cantidad: 25, total: 200000 },
                { nombre: 'Picada Para 2', cantidad: 8, total: 160000 }
              ].map((producto, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                  <div>
                    <p className="text-white font-medium">{producto.nombre}</p>
                    <p className="text-gray-400 text-sm">{producto.cantidad} unidades</p>
                  </div>
                  <div className="text-right">
                    <p className="text-green-400 font-bold">${producto.total.toLocaleString()}</p>
                    <Badge variant="secondary" className="bg-green-600/20 text-green-400">
                      #{index + 1}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Estado de pisos */}
        <Card className="bg-white/5 backdrop-blur-md border-red-900/20">
          <CardHeader>
            <CardTitle className="text-white">Estado de Pisos</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {PISOS.map((piso) => {
                const ocupadas = Math.floor(Math.random() * piso.mesas * 0.6);
                const porcentaje = Math.round((ocupadas / piso.mesas) * 100);
                
                return (
                  <div key={piso.number} className="p-4 bg-white/5 rounded-lg">
                    <div className="flex justify-between items-center mb-2">
                      <h3 className="text-white font-medium">Piso {piso.number}</h3>
                      <Badge variant={porcentaje > 70 ? "destructive" : porcentaje > 40 ? "default" : "secondary"}>
                        {porcentaje}%
                      </Badge>
                    </div>
                    <p className="text-gray-400 text-sm">{ocupadas} de {piso.mesas} mesas ocupadas</p>
                    <div className="w-full bg-gray-700 rounded-full h-2 mt-2">
                      <div 
                        className={`h-2 rounded-full ${
                          porcentaje > 70 ? 'bg-red-500' : porcentaje > 40 ? 'bg-yellow-500' : 'bg-green-500'
                        }`}
                        style={{ width: `${porcentaje}%` }}
                      ></div>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function ModalPedido({ pisoActual, mesaSeleccionada, mesas, setMesas, onCerrar, onAbrirCobro, user, saboresSopas }) {
  const mesaKey = `${pisoActual}-${mesaSeleccionada}`;
  const mesaData = mesas[mesaKey] || { pedidos: [], total: 0 };
  
  const [categoria, setCategoria] = useState('picadas');
  const [pedidoActual, setPedidoActual] = useState({
    tipo: 'picada',
    size: 'Personal',
    carnes: [],
    termino: 'Jugoso',
    precio: '',
    notas: '',
    cantidad: 1
  });

  const eliminarPedido = (idPedido) => {
    if (!confirm('¿Eliminar este item del pedido?')) return;
    
    const pedido = mesaData.pedidos.find(p => p.id === idPedido);
    const precioUnitario = pedido.tipo === 'picada' ? parseInt(pedido.precio) : pedido.precioItem;
    const precioTotal = precioUnitario * (pedido.cantidad || 1);
    
    const nuevosPedidos = mesaData.pedidos.filter(p => p.id !== idPedido);
    const nuevoTotal = mesaData.total - precioTotal;

    const mesaActualizada = {
      pedidos: nuevosPedidos,
      total: nuevoTotal,
      mesero: user.name,
      ultimaActualizacion: new Date().toISOString()
    };

    setMesas({
      ...mesas,
      [mesaKey]: mesaActualizada
    });
  };

  const cambiarCantidad = (idPedido, nuevaCantidad) => {
    if (nuevaCantidad < 1) return;
    
    const pedidoViejo = mesaData.pedidos.find(p => p.id === idPedido);
    const precioUnitario = pedidoViejo.tipo === 'picada' ? parseInt(pedidoViejo.precio) : pedidoViejo.precioItem;
    
    const diferencia = nuevaCantidad - (pedidoViejo.cantidad || 1);
    const nuevoTotal = mesaData.total + (precioUnitario * diferencia);

    const nuevosPedidos = mesaData.pedidos.map(p =>
      p.id === idPedido ? { ...p, cantidad: nuevaCantidad } : p
    );

    const mesaActualizada = {
      ...mesaData,
      pedidos: nuevosPedidos,
      total: nuevoTotal,
      mesero: user.name,
      ultimaActualizacion: new Date().toISOString()
    };

    setMesas({
      ...mesas,
      [mesaKey]: mesaActualizada
    });
  };

  const toggleEstadoPedido = (idPedido) => {
    const nuevosPedidos = mesaData.pedidos.map(p =>
      p.id === idPedido ? { ...p, enviado: !p.enviado } : p
    );

    const mesaActualizada = {
      ...mesaData,
      pedidos: nuevosPedidos,
      mesero: user.name,
      ultimaActualizacion: new Date().toISOString()
    };

    setMesas({
      ...mesas,
      [mesaKey]: mesaActualizada
    });
  };

  const enviarTodosACocina = () => {
    const pedidosPendientes = mesaData.pedidos.filter(p => !p.enviado);
    if (pedidosPendientes.length === 0) {
      alert('No hay pedidos pendientes para enviar');
      return;
    }

    const nuevosPedidos = mesaData.pedidos.map(p => ({ ...p, enviado: true }));

    const mesaActualizada = {
      ...mesaData,
      pedidos: nuevosPedidos,
      mesero: user.name,
      ultimaActualizacion: new Date().toISOString()
    };

    setMesas({
      ...mesas,
      [mesaKey]: mesaActualizada
    });
  };

  const agregarPedido = () => {
    if (categoria === 'picadas' && (!pedidoActual.precio || pedidoActual.carnes.length === 0)) {
      alert('Seleccione al menos una carne y especifique el precio');
      return;
    }

    const nuevoPedido = { ...pedidoActual, id: Date.now() };
    const precio = categoria === 'picadas' ? parseInt(pedidoActual.precio) : pedidoActual.precioItem;
    
    const nuevosPedidos = [...mesaData.pedidos, nuevoPedido];
    const nuevoTotal = mesaData.total + (precio * pedidoActual.cantidad);

    const mesaActualizada = {
      pedidos: nuevosPedidos,
      total: nuevoTotal,
      mesero: user.name,
      ultimaActualizacion: new Date().toISOString()
    };

    setMesas({
      ...mesas,
      [mesaKey]: mesaActualizada
    });

    // Reset solo para picadas
    if (categoria === 'picadas') {
      setPedidoActual({
        tipo: 'picada',
        size: 'Personal',
        carnes: [],
        termino: 'Jugoso',
        precio: '',
        notas: '',
        cantidad: 1
      });
    } else {
      setPedidoActual({
        ...pedidoActual,
        notas: ''
      });
    }
  };

  const toggleCarne = (carne) => {
    setPedidoActual(prev => ({
      ...prev,
      carnes: prev.carnes.includes(carne)
        ? prev.carnes.filter(c => c !== carne)
        : [...prev.carnes, carne]
    }));
  };

  const seleccionarItem = (item) => {
    const pedidoExistente = mesaData.pedidos.find(
      p => p.nombre === item.name && p.tipo === categoria
    );

    let nuevosPedidos;
    if (pedidoExistente) {
      nuevosPedidos = mesaData.pedidos.map(p =>
        p.id === pedidoExistente.id
          ? { ...p, cantidad: p.cantidad + 1 }
          : p
      );
    } else {
      nuevosPedidos = [...mesaData.pedidos, {
        id: Date.now(),
        tipo: categoria,
        nombre: item.name,
        precioItem: item.price,
        cantidad: 1,
        notas: ''
      }];
    }

    const nuevoTotal = mesaData.total + item.price;
    const mesaActualizada = {
      pedidos: nuevosPedidos,
      total: nuevoTotal,
      mesero: user.name,
      ultimaActualizacion: new Date().toISOString()
    };

    setMesas({
      ...mesas,
      [mesaKey]: mesaActualizada
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-6xl max-h-[90vh] overflow-hidden bg-white/5 backdrop-blur-md border-red-900/20">
        {/* Header */}
        <CardHeader className="border-b border-red-900/20">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white">Mesa {mesaSeleccionada}</CardTitle>
              <p className="text-gray-400 text-sm">Piso {pisoActual}</p>
            </div>
            <div className="flex items-center space-x-2">
              <Button
                onClick={onCerrar}
                variant="outline"
                size="sm"
                className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
              >
                ← Volver a mesas
              </Button>
              <Button
                onClick={onCerrar}
                variant="outline"
                size="sm"
                className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </CardHeader>

        <CardContent className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          <div className="space-y-6">
            {/* Categorías */}
            <div className="grid grid-cols-4 gap-2">
              {['picadas', 'sopas', 'bebidas', 'adicionales'].map((cat) => (
                <Button
                  key={cat}
                  onClick={() => setCategoria(cat)}
                  variant={categoria === cat ? "default" : "outline"}
                  className={`py-3 px-4 font-medium transition-all duration-300 ${
                    categoria === cat
                      ? 'bg-red-600 text-white hover:bg-red-700'
                      : 'bg-white/5 text-gray-400 hover:bg-white/10 border-red-900/20'
                  }`}
                >
                  {cat.charAt(0).toUpperCase() + cat.slice(1)}
                </Button>
              ))}
            </div>

            {/* Contenido según categoría */}
            {categoria === 'picadas' && (
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Tamaño</label>
                  <div className="grid grid-cols-4 gap-2">
                    {MENU_DATA.picadas.sizes.map(size => (
                      <Button
                        key={size}
                        onClick={() => setPedidoActual({...pedidoActual, size})}
                        variant={pedidoActual.size === size ? "default" : "outline"}
                        size="sm"
                        className={`transition-all ${
                          pedidoActual.size === size
                            ? 'bg-red-600 text-white hover:bg-red-700'
                            : 'bg-white/5 text-gray-400 border-red-900/20'
                        }`}
                      >
                        {size}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Carnes</label>
                  <div className="grid grid-cols-5 gap-2">
                    {MENU_DATA.picadas.carnes.map(carne => (
                      <Button
                        key={carne}
                        onClick={() => toggleCarne(carne)}
                        variant={pedidoActual.carnes.includes(carne) ? "default" : "outline"}
                        size="sm"
                        className={`transition-all ${
                          pedidoActual.carnes.includes(carne)
                            ? 'bg-red-600 text-white hover:bg-red-700'
                            : 'bg-white/5 text-gray-400 border-red-900/20'
                        }`}
                      >
                        {carne}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Término</label>
                  <div className="grid grid-cols-3 gap-2">
                    {MENU_DATA.picadas.terminos.map(termino => (
                      <Button
                        key={termino}
                        onClick={() => setPedidoActual({...pedidoActual, termino})}
                        variant={pedidoActual.termino === termino ? "default" : "outline"}
                        size="sm"
                        className={`transition-all ${
                          pedidoActual.termino === termino
                            ? 'bg-red-600 text-white hover:bg-red-700'
                            : 'bg-white/5 text-gray-400 border-red-900/20'
                        }`}
                      >
                        {termino}
                      </Button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">Precio</label>
                  <Input
                    type="number"
                    value={pedidoActual.precio}
                    onChange={(e) => setPedidoActual({...pedidoActual, precio: e.target.value})}
                    placeholder="Ingrese el precio"
                    className="bg-white/5 border-red-900/30 text-white"
                  />
                </div>
              </div>
            )}

            {/* Sopas */}
            {categoria === 'sopas' && (
              <div className="space-y-4">
                <div className="text-center p-4 bg-white/5 rounded-lg">
                  <p className="text-white font-medium">Precio fijo: $9.000</p>
                  <p className="text-gray-400 text-sm">Selecciona el sabor disponible</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {saboresSopas.map(sabor => (
                    <Button
                      key={sabor}
                      onClick={() => seleccionarItem({ name: sabor, price: MENU_DATA.sopas.price })}
                      variant="outline"
                      className="p-4 h-auto text-left transition-all bg-white/5 text-gray-300 hover:bg-red-600 hover:text-white border-red-900/20 hover:border-red-600"
                    >
                      <div>
                        <p className="font-medium">{sabor}</p>
                        <p className="text-sm opacity-80">$9.000</p>
                        <p className="text-xs opacity-60">Click para agregar</p>
                      </div>
                    </Button>
                  ))}
                </div>
              </div>
            )}
            
            {/* Bebidas */}
            {categoria === 'bebidas' && (
              <div className="space-y-6">
                {Object.entries(MENU_DATA.bebidas).map(([subcategoria, items]) => (
                  <div key={subcategoria}>
                    <h4 className="text-white font-medium mb-3">{subcategoria}</h4>
                    <div className="grid grid-cols-2 gap-3">
                      {items.map(item => (
                        <Button
                          key={item.name}
                          onClick={() => seleccionarItem(item)}
                          variant="outline"
                          className="p-3 h-auto text-left transition-all bg-white/5 text-gray-300 hover:bg-red-600 hover:text-white border-red-900/20 hover:border-red-600"
                        >
                          <div>
                            <p className="font-medium text-sm">{item.name}</p>
                            <p className="text-sm opacity-80">${item.price.toLocaleString()}</p>
                          </div>
                        </Button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
            
            {/* Adicionales */}
            {categoria === 'adicionales' && (
              <div className="space-y-4">
                <div className="text-center p-4 bg-white/5 rounded-lg">
                  <p className="text-yellow-400 font-medium">Precios Fijos - No Editables</p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  {MENU_DATA.adicionales.map(item => (
                    <Button
                      key={item.name}
                      onClick={() => seleccionarItem(item)}
                      variant="outline"
                      className="p-4 h-auto text-left transition-all bg-white/5 text-gray-300 hover:bg-green-600 hover:text-white border-green-900/20 hover:border-green-600"
                    >
                      <div>
                        <p className="font-medium">{item.name}</p>
                        <p className="text-sm opacity-80">${item.price.toLocaleString()}</p>
                        <p className="text-xs opacity-60 text-green-400">Precio fijo</p>
                      </div>
                    </Button>
                  ))}
                </div>
              </div>
            )}

            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">Notas especiales</label>
              <Textarea
                value={pedidoActual.notas}
                onChange={(e) => setPedidoActual({...pedidoActual, notas: e.target.value})}
                placeholder="Sin cebolla, sin sal..."
                className="bg-white/5 border-red-900/30 text-white resize-none"
                rows={3}
              />
            </div>

            {categoria === 'picadas' && (
              <Button
                onClick={agregarPedido}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                <Plus className="w-4 h-4 mr-2" />
                Agregar Picada al Pedido
              </Button>
            )}

            {/* Lista de pedidos */}
            {mesaData.pedidos.length > 0 && (
              <Card className="bg-white/5 border-red-900/20">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-center">
                    <CardTitle className="text-white text-lg">Pedidos de la mesa</CardTitle>
                    <Button
                      onClick={enviarTodosACocina}
                      size="sm"
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <Send className="w-4 h-4 mr-2" />
                      Enviar todos a cocina
                    </Button>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  {mesaData.pedidos.map((p) => {
                    const precioUnitario = p.tipo === 'picada' ? parseInt(p.precio) : p.precioItem;
                    const precioTotal = precioUnitario * (p.cantidad || 1);
                    
                    return (
                      <Card key={p.id} className="bg-white/5 border-red-900/20">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-2 mb-2">
                                <Button
                                  onClick={() => toggleEstadoPedido(p.id)}
                                  size="sm"
                                  variant="outline"
                                  className={`p-1 transition-all ${
                                    p.enviado 
                                      ? 'bg-green-600 hover:bg-green-700 border-green-600 text-white' 
                                      : 'bg-yellow-600 hover:bg-yellow-700 border-yellow-600 text-white'
                                  }`}
                                >
                                  {p.enviado ? (
                                    <CheckCircle className="w-4 h-4" />
                                  ) : (
                                    <Clock className="w-4 h-4" />
                                  )}
                                </Button>
                                <Badge variant={p.enviado ? "default" : "secondary"}>
                                  {p.enviado ? 'En cocina' : 'Pendiente'}
                                </Badge>
                                <p className="text-white font-medium">
                                  {p.tipo === 'picada' ? `Picada ${p.size}` : p.nombre}
                                </p>
                              </div>
                              {p.tipo === 'picada' && (
                                <p className="text-gray-400 text-sm">{p.carnes.join(', ')} - {p.termino}</p>
                              )}
                              {p.notas && <p className="text-gray-400 text-sm italic">"{p.notas}"</p>}
                            </div>

                            <div className="flex items-center space-x-2">
                              <div className="flex items-center space-x-1">
                                <Button
                                  onClick={() => cambiarCantidad(p.id, (p.cantidad || 1) - 1)}
                                  size="sm"
                                  variant="outline"
                                  className="bg-red-600 hover:bg-red-700 border-red-600 text-white p-1"
                                >
                                  <Minus className="w-3 h-3" />
                                </Button>
                                <span className="text-white px-2">{p.cantidad || 1}</span>
                                <Button
                                  onClick={() => cambiarCantidad(p.id, (p.cantidad || 1) + 1)}
                                  size="sm"
                                  variant="outline"
                                  className="bg-green-600 hover:bg-green-700 border-green-600 text-white p-1"
                                >
                                  <Plus className="w-3 h-3" />
                                </Button>
                              </div>

                              <div className="text-right">
                                <p className="text-white font-bold">${precioTotal.toLocaleString()}</p>
                                {(p.cantidad || 1) > 1 && (
                                  <p className="text-gray-400 text-xs">${precioUnitario.toLocaleString()} c/u</p>
                                )}
                              </div>

                              <Button
                                onClick={() => eliminarPedido(p.id)}
                                size="sm"
                                variant="outline"
                                className="bg-red-600/20 hover:bg-red-600 text-red-400 hover:text-white border-red-600/50 p-2"
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}

                  <Separator className="my-4 bg-red-900/20" />

                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <div>
                        <p className="text-2xl font-bold text-white">
                          Total: ${mesaData.total.toLocaleString()}
                        </p>
                      </div>
                      <div className="text-right text-sm text-gray-400">
                        <p>{mesaData.pedidos.filter(p => p.enviado).length} de {mesaData.pedidos.length} en cocina</p>
                        <p>{mesaData.pedidos.reduce((sum, p) => sum + (p.cantidad || 1), 0)} items</p>
                      </div>
                    </div>
                    
                    {/* Botón de Cobro */}
                    {mesaData.pedidos.length > 0 && (
                      <div className="flex justify-center">
                        <Button
                          onClick={onAbrirCobro}
                          className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg font-medium"
                          size="lg"
                        >
                          <Calculator className="w-5 h-5 mr-2" />
                          Procesar Cobro - ${mesaData.total.toLocaleString()}
                        </Button>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function ModalCobro({ pisoActual, mesaSeleccionada, mesaData, onCerrar, onProcesarCobro }) {
  const [metodoPago, setMetodoPago] = useState('efectivo');
  const [montoRecibido, setMontoRecibido] = useState('');
  
  const cambio = montoRecibido ? Math.max(0, parseInt(montoRecibido) - mesaData.total) : 0;
  
  const confirmarCobro = () => {
    if (metodoPago === 'efectivo' && (!montoRecibido || parseInt(montoRecibido) < mesaData.total)) {
      alert('El monto recibido debe ser mayor o igual al total');
      return;
    }
    
    onProcesarCobro({ ...mesaData, metodoPago, montoRecibido: parseInt(montoRecibido) || mesaData.total });
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-md bg-white/5 backdrop-blur-md border-red-900/20">
        <CardHeader className="border-b border-red-900/20">
          <div className="flex items-center justify-between">
            <CardTitle className="text-white">Procesar Cobro</CardTitle>
            <Button
              onClick={onCerrar}
              variant="outline"
              size="sm"
              className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="p-6 space-y-6">
          <div className="text-center">
            <p className="text-gray-400">Mesa {mesaSeleccionada} - Piso {pisoActual}</p>
            <p className="text-3xl font-bold text-white mt-2">
              Total: ${mesaData.total.toLocaleString()}
            </p>
          </div>
          
          <Separator className="bg-red-900/20" />
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-300 mb-2">
                Método de Pago
              </label>
              <div className="grid grid-cols-2 gap-2">
                {['efectivo', 'tarjeta'].map((metodo) => (
                  <Button
                    key={metodo}
                    onClick={() => setMetodoPago(metodo)}
                    variant={metodoPago === metodo ? "default" : "outline"}
                    className={`transition-all ${
                      metodoPago === metodo
                        ? 'bg-red-600 text-white hover:bg-red-700'
                        : 'bg-white/5 text-gray-400 border-red-900/20'
                    }`}
                  >
                    {metodo.charAt(0).toUpperCase() + metodo.slice(1)}
                  </Button>
                ))}
              </div>
            </div>
            
            {metodoPago === 'efectivo' && (
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  Monto Recibido
                </label>
                <Input
                  type="number"
                  value={montoRecibido}
                  onChange={(e) => setMontoRecibido(e.target.value)}
                  placeholder="Ingrese el monto recibido"
                  className="bg-white/5 border-red-900/30 text-white"
                />
                {montoRecibido && cambio > 0 && (
                  <p className="text-yellow-400 text-sm mt-2">
                    Cambio: ${cambio.toLocaleString()}
                  </p>
                )}
              </div>
            )}
          </div>
          
          <Separator className="bg-red-900/20" />
          
          <div className="space-y-2">
            <h4 className="text-white font-medium">Resumen del Pedido:</h4>
            {mesaData.pedidos.map((pedido, index) => (
              <div key={index} className="flex justify-between text-sm">
                <span className="text-gray-300">
                  {pedido.tipo === 'picada' 
                    ? `Picada ${pedido.size}` 
                    : pedido.nombre
                  } x{pedido.cantidad}
                </span>
                <span className="text-white">
                  ${((pedido.tipo === 'picada' ? parseInt(pedido.precio) : pedido.precioItem) * pedido.cantidad).toLocaleString()}
                </span>
              </div>
            ))}
          </div>
          
          <div className="flex space-x-3">
            <Button
              onClick={onCerrar}
              variant="outline"
              className="flex-1 border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
            >
              Cancelar
            </Button>
            <Button
              onClick={confirmarCobro}
              className="flex-1 bg-green-600 hover:bg-green-700 text-white"
            >
              Confirmar Cobro
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function ModalAnalisis({ historialVentas, onCerrar }) {
  // Cálculos de análisis
  const totalVentas = historialVentas.reduce((sum, venta) => sum + venta.total, 0);
  const ventasHoy = historialVentas.filter(venta => {
    const hoy = new Date().toDateString();
    const fechaVenta = new Date(venta.fecha).toDateString();
    return hoy === fechaVenta;
  });
  
  const totalHoy = ventasHoy.reduce((sum, venta) => sum + venta.total, 0);
  const promedioTicket = ventasHoy.length > 0 ? totalHoy / ventasHoy.length : 0;
  
  // Productos más vendidos
  const productosVendidos = {};
  historialVentas.forEach(venta => {
    venta.pedidos.forEach(pedido => {
      const nombre = pedido.tipo === 'picada' ? `Picada ${pedido.size}` : pedido.nombre;
      const cantidad = pedido.cantidad || 1;
      const precio = pedido.tipo === 'picada' ? parseInt(pedido.precio) : pedido.precioItem;
      
      if (!productosVendidos[nombre]) {
        productosVendidos[nombre] = { cantidad: 0, total: 0 };
      }
      productosVendidos[nombre].cantidad += cantidad;
      productosVendidos[nombre].total += precio * cantidad;
    });
  });
  
  const topProductos = Object.entries(productosVendidos)
    .sort(([,a], [,b]) => b.cantidad - a.cantidad)
    .slice(0, 5);
  
  // Ventas por mesero
  const ventasPorMesero = {};
  historialVentas.forEach(venta => {
    if (!ventasPorMesero[venta.mesero]) {
      ventasPorMesero[venta.mesero] = { ventas: 0, total: 0 };
    }
    ventasPorMesero[venta.mesero].ventas += 1;
    ventasPorMesero[venta.mesero].total += venta.total;
  });

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4 z-50">
      <Card className="w-full max-w-6xl max-h-[90vh] overflow-hidden bg-white/5 backdrop-blur-md border-red-900/20">
        <CardHeader className="border-b border-red-900/20">
          <div className="flex items-center justify-between">
            <CardTitle className="text-white">Análisis de Ventas</CardTitle>
            <Button
              onClick={onCerrar}
              variant="outline"
              size="sm"
              className="border-red-600 text-red-400 hover:bg-red-600 hover:text-white"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        
        <CardContent className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]">
          <div className="space-y-6">
            {/* Métricas principales */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="bg-white/5 border-red-900/20">
                <CardContent className="p-4 text-center">
                  <p className="text-2xl font-bold text-green-400">${totalHoy.toLocaleString()}</p>
                  <p className="text-sm text-gray-400">Ventas Hoy</p>
                </CardContent>
              </Card>
              
              <Card className="bg-white/5 border-red-900/20">
                <CardContent className="p-4 text-center">
                  <p className="text-2xl font-bold text-blue-400">{ventasHoy.length}</p>
                  <p className="text-sm text-gray-400">Mesas Atendidas</p>
                </CardContent>
              </Card>
              
              <Card className="bg-white/5 border-red-900/20">
                <CardContent className="p-4 text-center">
                  <p className="text-2xl font-bold text-yellow-400">${Math.round(promedioTicket).toLocaleString()}</p>
                  <p className="text-sm text-gray-400">Promedio Ticket</p>
                </CardContent>
              </Card>
              
              <Card className="bg-white/5 border-red-900/20">
                <CardContent className="p-4 text-center">
                  <p className="text-2xl font-bold text-purple-400">{historialVentas.length}</p>
                  <p className="text-sm text-gray-400">Total Ventas</p>
                </CardContent>
              </Card>
            </div>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Productos más vendidos */}
              <Card className="bg-white/5 border-red-900/20">
                <CardHeader>
                  <CardTitle className="text-white">Productos Más Vendidos</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {topProductos.length > 0 ? topProductos.map(([nombre, datos], index) => (
                      <div key={nombre} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <p className="text-white font-medium">{nombre}</p>
                          <p className="text-gray-400 text-sm">{datos.cantidad} unidades</p>
                        </div>
                        <div className="text-right">
                          <p className="text-green-400 font-bold">${datos.total.toLocaleString()}</p>
                          <Badge variant="secondary" className="bg-green-600/20 text-green-400">
                            #{index + 1}
                          </Badge>
                        </div>
                      </div>
                    )) : (
                      <p className="text-gray-400 text-center py-4">No hay datos de ventas aún</p>
                    )}
                  </div>
                </CardContent>
              </Card>
              
              {/* Ventas por mesero */}
              <Card className="bg-white/5 border-red-900/20">
                <CardHeader>
                  <CardTitle className="text-white">Rendimiento por Mesero</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(ventasPorMesero).length > 0 ? Object.entries(ventasPorMesero).map(([mesero, datos]) => (
                      <div key={mesero} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                        <div>
                          <p className="text-white font-medium">{mesero}</p>
                          <p className="text-gray-400 text-sm">{datos.ventas} mesas atendidas</p>
                        </div>
                        <div className="text-right">
                          <p className="text-blue-400 font-bold">${datos.total.toLocaleString()}</p>
                          <p className="text-gray-400 text-xs">
                            Promedio: ${Math.round(datos.total / datos.ventas).toLocaleString()}
                          </p>
                        </div>
                      </div>
                    )) : (
                      <p className="text-gray-400 text-center py-4">No hay datos de meseros aún</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Historial de ventas */}
            <Card className="bg-white/5 border-red-900/20">
              <CardHeader>
                <CardTitle className="text-white">Historial de Ventas Recientes</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-60 overflow-y-auto">
                  {historialVentas.length > 0 ? historialVentas.slice(-10).reverse().map((venta) => (
                    <div key={venta.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg">
                      <div>
                        <p className="text-white font-medium">Mesa {venta.mesa.split('-')[1]} - Piso {venta.mesa.split('-')[0]}</p>
                        <p className="text-gray-400 text-sm">
                          {new Date(venta.fecha).toLocaleString()} - {venta.mesero}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="text-green-400 font-bold">${venta.total.toLocaleString()}</p>
                        <p className="text-gray-400 text-xs">{venta.pedidos.length} items</p>
                      </div>
                    </div>
                  )) : (
                    <p className="text-gray-400 text-center py-4">No hay ventas registradas aún</p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}